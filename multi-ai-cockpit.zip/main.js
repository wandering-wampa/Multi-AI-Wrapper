const { app, BrowserWindow, BrowserView, ipcMain } = require("electron");
const path = require("path");

let mainWindow;
let view;

const MODEL_URLS = {
  chatgpt: "https://chatgpt.com/",
  claude: "https://claude.ai/",
  gemini: "https://gemini.google.com/app"
};

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 900,
    minHeight: 600,
    title: "Multi-AI Cockpit",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true
    }
  });

  mainWindow.loadFile("index.html");

  view = new BrowserView({
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true
    }
  });

  mainWindow.setBrowserView(view);
  resizeView();

  view.webContents.loadURL(MODEL_URLS.chatgpt);

  mainWindow.on("resize", () => {
    resizeView();
  });

  mainWindow.on("closed", () => {
    mainWindow = null;
  });
}

function resizeView() {
  if (!mainWindow || !view) return;
  const [winWidth, winHeight] = mainWindow.getContentSize();
  const topBarHeight = 48;
  view.setBounds({ x: 0, y: topBarHeight, width: winWidth, height: winHeight - topBarHeight });
  view.setAutoResize({ width: true, height: true });
}

ipcMain.on("switch-model", (event, modelName) => {
  const url = MODEL_URLS[modelName];
  if (!url) return;
  view.webContents.loadURL(url);
});

app.whenReady().then(() => {
  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});
